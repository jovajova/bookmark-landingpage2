<a href="<?php echo esc_url( $link ); ?>"
   class="export-view"><?php echo esc_html( ! empty( $frm_options['export_link_text'] ) ? $frm_options['export_link_text'] : __( 'Export to CSV', 'formidable-export_view' ) ); ?></a>
