<?php
/*
Plugin Name: Formidable Bootstrap
Description: Instantly add Bootstrap styling to your forms
Version: 1.02.02
Plugin URI: http://formidablepro.com/
Author URI: http://strategy11.com
Author: Strategy11
*/

include(dirname(__FILE__) .'/controllers/FrmBtspAppController.php');
$obj = new FrmBtspAppController();

