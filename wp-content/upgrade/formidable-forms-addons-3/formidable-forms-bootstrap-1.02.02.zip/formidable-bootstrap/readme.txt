= 1.02.02 =
* Enhancement: Allow prepend and append options with dropdowns.

= 1.02.01 =
* Enhancement: Update Bootstrap version to 3.3.7.
* Enhancement: Add prepend and append options to Lookup > Text fields

= 1.02 =
* Enhancement: Update Bootstrap version to 3.3.6.
* Fix: Make sure modified [input] tag works well with Bootstrap append.
* Fix: Add Bootstrap ID so automatic updates work in the future.
* Fix: Make sure Lookup checkbox and radio fields look nice.

= 1.01.04 =
* Prevent errors with Formidable disabled

= 1.01.03 =
* Get updates from FormidablePro.com

= 1.01.02 =
* Always add the has-error class for fields in error regardless of the error setting

= 1.01.01 =
* Keep the frm_submit class on the submit button so the submit button will use Formidable styling
* Fix layout issue on Formidable -> Global settings page

= 1.01 =
* Update to Bootstap version 3.3
* Change HTML for fields using prepend and append options for a cleaner, more consistent output when labels are shown

= 1.0 =
* Add button classes to previous button
* Remove the frm_submit class to prevent Formidable styling from overriding the buttons
* Switch to using Bootstrap from CDN
* Option to only load Bootstrap css when a form is loaded or not at all
* Option to show error messages on form

= 1.0b2 =
* Moved a few classes around for better compatibility
* Switched from using frm_submit_button_action and frm_back_button_action hooks to frm_submit_button_class and frm_back_button_class
