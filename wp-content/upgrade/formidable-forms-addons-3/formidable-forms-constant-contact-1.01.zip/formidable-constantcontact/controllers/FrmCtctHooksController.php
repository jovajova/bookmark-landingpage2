<?php

class FrmCtctHooksController {

	public static function load_hooks() {
		add_action( 'frm_entry_form', 'FrmCtctAppController::hidden_form_fields', 10, 2 );

		add_action( 'frm_trigger_constantcontact_action', 'FrmCtctAppController::trigger_constantcontact', 10, 3 );
		add_action( 'frm_registered_form_actions', 'FrmCtctSettingsController::register_actions' );

		add_action( 'plugins_loaded', 'FrmCtctAppController::load_lang' );

		self::load_admin_hooks();
	}

	public static function load_admin_hooks() {
		if ( ! is_admin() ) {
			return;
		}

		add_action( 'admin_init', 'FrmCtctAppController::include_updater' );
		add_action( 'admin_enqueue_scripts', 'FrmCtctHooksController::add_scripts' );
		add_action( 'after_plugin_row_formidable-constantcontact/formidable-constantcontact.php', 'FrmCtctAppController::min_version_notice' );

		add_action( 'frm_add_settings_section', 'FrmCtctSettingsController::add_settings_section' );

		add_action( 'wp_ajax_clear_ctct_lists_cache', 'FrmCtctAction::clear_cache' );
	}

	public static function add_scripts() {
		if ( self::is_form_settings_page() ) {
			$url = FrmCtctAppController::plugin_url();
			wp_enqueue_style( 'frmctct', $url . '/css/frmctct.css', array(), 1 );
			wp_register_script( 'frmctct', $url . '/js/frmctct.js', array(), 1 );

			wp_localize_script(
				'frmctct',
				'frmctctGlobal',
				array(
					'nonce' => wp_create_nonce( 'frmctct_ajax' ),
				)
			);
			wp_enqueue_script( 'frmctct' );
		}
	}

	/**
	 * Check if the current page is the form settings page
	 *
	 * @since 2.01
	 *
	 * @return bool
	 */
	private static function is_form_settings_page() {
		if ( method_exists( 'FrmAppHelper', 'simple_get' ) ) {
			$page = FrmAppHelper::simple_get( 'page', 'sanitize_title' );
			$action = FrmAppHelper::simple_get( 'frm_action', 'sanitize_title' );
			return ( 'formidable' === $page && 'settings' === $action );
		} else {
			return false;
		}
	}
}
