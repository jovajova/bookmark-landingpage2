<?php
class FrmCtctSettingsController {

	public static function add_settings_section( $sections ) {
		$sections['constantcontact'] = array(
			'class'    => __CLASS__,
			'function' => 'route',
			'name'     => 'Constant Contact',
		);
		return $sections;
	}

	public static function register_actions( $actions ) {
		$actions['constantcontact'] = 'FrmCtctAction';

		include_once FrmCtctAppController::path() . '/models/FrmCtctAction.php';

		return $actions;
	}

	/**
	 * @since 2.01
	 */
	public static function get_settings() {
		global $frm_ctct_settings;
		if ( empty( $frm_ctct_settings ) ) {
			$frm_ctct_settings = new FrmCtctSettings();
		}
		return $frm_ctct_settings;
	}

	public static function display_form() {
		$frm_ctct_settings = self::get_settings();
		$settings = $frm_ctct_settings->settings;
		$ctct_api = new FrmCtctAPI();

		require_once FrmCtctAppController::path() . '/views/settings/form.php';
	}

	public static function process_form() {
		$frm_ctct_settings = self::get_settings();

		$process_form = FrmAppHelper::get_post_param( 'process_form', '', 'sanitize_text_field' );
		if ( wp_verify_nonce( $process_form, 'process_form_nonce' ) ) {
			$frm_ctct_settings->update( $_POST );
			$frm_ctct_settings->store();
		}

		self::display_form();
	}

	public static function route() {
		$action = FrmAppHelper::get_param( 'action' );
		if ( 'process-form' === $action ) {
			return self::process_form();
		} else {
			return self::display_form();
		}
	}
}
