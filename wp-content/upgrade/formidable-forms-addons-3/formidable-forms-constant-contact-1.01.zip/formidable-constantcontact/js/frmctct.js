( function( $ ) {
	$( function() {
		$( 'body' ).on( 'click', '#clrcache-constantcontact', function( event ) {
			event.preventDefault();
			$( '.clrcache-constantcontact-spinner' ).css( 'visibility', 'visible' );
			data = {
				action: 'clear_ctct_lists_cache',
				security: frmctctGlobal.nonce
			};
			$.post( ajaxurl, data, function( result, textStatus, xhr ) {
				$( '.clrcache-constantcontact-spinner' ).css( 'visibility', 'hidden' );
				location.reload();
			} );

		} );
	} );
} )( jQuery );
