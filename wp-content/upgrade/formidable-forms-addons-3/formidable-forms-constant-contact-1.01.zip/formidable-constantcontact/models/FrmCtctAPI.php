<?php
class FrmCtctAPI {

	protected $api_base_url = 'https://api.cc.email/v3';

	protected $entry_id = 0;

	protected $api_key = '5ccb8551-6e77-4703-b8f7-1fc1d8d9627b';

	protected $secret  = 'EE0E28wDy7ssRUaqo04oRQ';

	protected $access_token  = '';

	protected $refresh_token = '';

	protected $action;


	public function __construct() {
		$settings = new FrmCtctSettings();
		$this->access_token  = $settings->settings->access_token;
		$this->refresh_token = $settings->settings->refresh_token;
	}

	public function auth_url() {
		$current_page = admin_url( 'admin.php?page=formidable-settings&t=constantcontact_settings' );
		$redirect_url = add_query_arg( 'admin', $current_page, 'https://formidableforms.com/constant-contact-authorization/' );
		$url = 'https://api.cc.email/v3/idfed/';
		$params = array(
			'client_id'     => $this->api_key,
			'redirect_uri'  => 'https://formidableforms.com/constant-contact-authorization/',
			'scope'         => 'contact_data',
			'response_type' => 'code',
		);
		return add_query_arg( $params, $url );
	}

	public function get_access_token( $auth_code ) {
		$body = array(
			'code'         => $auth_code,
			'grant_type'   => 'authorization_code',
			'redirect_uri' => 'https://formidableforms.com/constant-contact-authorization/',
		);

		return $this->token_request( $body );
	}

	/**
	 * @since 1.0
	 *
	 * @param mixed $response
	 * @return bool true if tokens were refreshed
	 */
	private function maybe_refresh_access_token( $response ) {
		if ( ! $this->is_unauthorized( $response ) || empty( $this->refresh_token ) ) {
			return false;
		}

		$body = array(
			'refresh_token' => $this->refresh_token,
			'grant_type'    => 'refresh_token',
		);

		$refreshed = false;

		$response = $this->token_request( $body );
		if ( 'unknown, invalid, or expired refresh token' === $response ) {
			$this->clear_tokens();
		} else {
			$this->save_tokens( $response );
			if ( ! empty( $response ) && isset( $response->access_token ) ) {
				$refreshed = true;
			}
		}

		return $refreshed;
	}

	private function token_request( $body ) {
		$url = 'https://idfed.constantcontact.com/as/token.oauth2';
		$req_args = array(
			'method'  => 'POST',
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $this->api_key . ':' . $this->secret ),
			),
			'body'    => $body,
		);

		$result = wp_remote_request( $url, $req_args );

		if ( is_wp_error( $result ) ) {
			$response = $result->get_error_message();
		} else {
			$response = json_decode( wp_remote_retrieve_body( $result ) );
			if ( is_object( $response ) && isset( $response->error ) ) {
				$response = $response->error_description;
			} else {
				$this->save_tokens( $response );
			}
		}

		return $response;
	}

	/**
	 * Get Lists
	 *
	 * @since  1.0
	 * @author Aman Saini
	 * @return Custom Lists Array
	 */
	public function get_lists() {
		$cached_lists = get_transient( 'frm-ctct-lists' );
		if ( ! empty( $cached_lists ) ) {
			return $cached_lists;
		}
		$lists = array();
		$response = $this->make_request( '/contact_lists/', 'GET' );

		if ( is_object( $response ) && isset( $response->lists ) ) {
			foreach ( $response->lists as $list_row ) {
				$lists[] = array(
					'label' => $list_row->name,
					'id'    => $list_row->list_id,
				);
			}
			set_transient( 'frm-ctct-lists', $lists, 60 * 60 * 60 );
			$this->set_last_checked();
		} elseif ( $this->is_unauthorized( $response ) ) {
			echo '<div class="notice inline notice-warning">' .
				sprintf(
					/* translators: %1$s: Start link HTML, %2$s: end link HTML */
					esc_html__( 'The Constant Contact authorization has expired. Please return to the %1$sGlobal settings%2$s and reauthorize.', 'formidable-ctct' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=formidable-settings&t=constantcontact_settings' ) ) . '" target="_blank" rel="noopener">',
					'</a>'
				) .
				'</div>';
			wp_die();
		} else {
			$this->show_error( $response );
		}
		return $lists;
	}

	/**
	 * Get custom fields
	 *
	 * @since  1.0
	 * @return array Custom fields
	 */
	public function get_custom_fields() {
		$cached = get_transient( 'frm-ctct-fields' );
		if ( ! empty( $cached ) ) {
			return $cached;
		}

		$fields = array();
		$response = $this->make_request( '/contact_custom_fields/', 'GET' );

		if ( is_object( $response ) && isset( $response->custom_fields ) ) {
			foreach ( $response->custom_fields as $custom_field ) {
				if ( 'date' === $custom_field->type ) {
					$new_field = array(
						'name' => $custom_field->label,
						'type' => array( 'date' ),
					);
				} else {
					$new_field = $custom_field->label;
				}
				$fields[ $custom_field->custom_field_id ] = $new_field;
			}
			set_transient( 'frm-ctct-fields', $fields, 60 * 60 * 60 );
			$this->set_last_checked();
		} else {
			$this->show_error( $response );
		}

		return $fields;
	}

	private function set_last_checked() {
		$settings = new FrmCtctSettings();
		$settings->settings->last_checked = time();
		$settings->store();
	}

	/**
	 * If the tokens are no longer valid, clear them out
	 *
	 * @since 1.0
	 */
	private function clear_tokens() {
		$settings = new FrmCtctSettings();
		$settings->settings->refresh_token = '';
		$settings->settings->access_token  = '';
		$settings->settings->last_checked  = '';
		$this->refresh_token = '';
		$this->access_token  = '';
		$settings->store();
	}

	/**
	 * After new tokens are generated, save them
	 *
	 * @since 1.0
	 */
	private function save_tokens( $response ) {
		$settings = new FrmCtctSettings();
		$this->set_tokens( $response, $settings );
		$settings->store();
	}

	/**
	 * Add tokens to the settings to be saved later
	 *
	 * @since 1.0
	 */
	public function set_tokens( $response, &$settings ) {
		if ( ! empty( $response ) && isset( $response->access_token ) ) {
			$settings->settings->access_token  = $response->access_token;
			$settings->settings->refresh_token = $response->refresh_token;
			$settings->settings->last_checked  = time();
			$settings->settings->auth_code     = '';
			$this->refresh_token = $response->refresh_token;
			$this->access_token  = $response->access_token;
		}
	}

	/**
	 * Add data to ConstantContact Object
	 *
	 * @since  1.0
	 * @author Aman Saini
	 * @return Status Code
	 */
	public function create_or_update_contact( $data, $atts = array() ) {
		$settings = get_option( 'frm_ctct_options' );
		$this->set_entry( $atts );
		//check if contact already exists
		$contact_exists = $this->make_request( '/contacts', 'GET', array( 'email' => $data['email_address']['address'] ) );
		if ( is_object( $contact_exists ) && ! empty( $contact_exists->contacts ) ) {
			$contact = reset( $contact_exists->contacts );

			// update existing contact
			$data['update_source'] = 'Contact';
			$response = $this->make_request( '/contacts/' . $contact->contact_id, 'PUT', null, $data );
		} else {
			// create new contact
			$data['create_source'] = 'Contact';
			$response = $this->make_request( '/contacts', 'POST', null, $data );
		}

		if ( ! empty( $settings->debug_mode ) && ! empty( $response ) ) {
			echo '<h4>' . esc_html__( 'Debug Mode Enabled. Disable it after testing from Formidable -> Global Settings -> Constant Contact', 'formidable-ctct' ) . '</h4>';
			$this->show_error( $response );
		}
	}

	private function set_entry( $atts ) {
		if ( isset( $atts['entry'] ) ) {
			$this->entry_id  = $atts['entry']->id;
			$this->action = $atts['action'];
		}
	}

	/**
	 * @param boolean $string
	 * @param string $method - GET, POST, ...
	 * @param string $uri - The url for the API request
	 * @param array $params
	 * @param array $atts - includes the entry and form action
	 */
	private function make_request( $uri, $method, $params = array(), $data = array() ) {
		//setup query params
		$params['api_key'] = $this->api_key;
		$querystring = urldecode( http_build_query( $params ) );
		$url = $this->api_base_url . $uri . '?' . $querystring;

		$req_args = array(
			'method'    => $method,
			'headers'   => array(
				'content-type'  => 'application/json',
				'Authorization' => 'Bearer ' . $this->access_token,
			),
		);

		if ( ! empty( $data ) ) {
			$req_args['body'] = json_encode( $data );
		}

		$result = wp_remote_request( $url, $req_args );

		$this->log_results(
			array(
				'response' => $result,
				'headers'  => $req_args['headers'],
				'body'     => json_encode( $data ),
				'url'      => $url,
			)
		);

		// handle response
		if ( is_wp_error( $result ) ) {
			$response = $result->get_error_message();
		} else {
			//no error
			$response = json_decode( wp_remote_retrieve_body( $result ) );
		}

		$refreshed = $this->maybe_refresh_access_token( $response, $req_args );
		if ( $refreshed ) {
			$response = $this->make_request( $uri, $method, $params, $data );
		}

		return $response;
	}

	private function show_error( $response ) {
		echo '<pre>';
		echo esc_html( print_r( $response, 1 ) );
		echo '</pre>';
		wp_die();
	}

	private function is_unauthorized( $response ) {
		return is_object( $response ) && isset( $response->error_key ) && 'unauthorized' === $response->error_key;
	}

	public function log_results( $atts ) {
		if ( ! class_exists( 'FrmLog' ) || empty( $this->entry_id ) ) {
			return;
		}

		$body    = wp_remote_retrieve_body( $atts['response'] );
		$content = $this->process_response( $atts['response'], $body );
		$message = isset( $content['message'] ) ? $content['message'] : '';

		$headers = '';
		$this->array_to_list( $atts['headers'], $headers );

		$content = array(
			'title'   => __( 'Constant Contact:', 'formidable-ctct' ) . ' ' . $this->action->post_title,
			'content' => (array) $body,
			'fields'  => array(
				'entry'   => $this->entry_id,
				'action'  => $this->action->ID,
				'code'    => isset( $content['code'] ) ? $content['code'] : '',
				'url'     => $atts['url'],
				'message' => $message,
				'request' => $atts['body'],
			),
		);
		$log = new FrmLog();
		$log->add( $content );
	}

	private function process_response( $response, $body ) {
		$processed = array(
			'message' => '',
			'code'    => 'FAIL',
		);

		if ( is_wp_error( $response ) ) {
			$processed['message'] = $response->get_error_message();
		} elseif ( 'error' === $body || is_wp_error( $body ) ) {
			$processed['message'] = __( 'You had an HTTP connection error', 'formidable-api' );
		} elseif ( isset( $response->error_key ) ) {
			$processed['message'] = $response->error_key . ':' . $response->error_message;
		} elseif ( isset( $response['response'] ) && isset( $response['response']['code'] ) ) {
			$processed['code'] = $response['response']['code'];
			$processed['message'] = $response['body'];
		}

		return $processed;
	}

	private function array_to_list( $array, &$list ) {
		foreach ( $array as $k => $v ) {
			$list .= "\r\n" . $k . ': ' . $v;
		}
	}
}
