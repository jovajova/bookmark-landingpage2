<?php
class FrmCtctSettings {
	public $settings;

	public $option_name = 'frm_ctct_options';

	public function __construct() {
		$this->set_default_options();
	}

	private function default_options() {
		return array(
			'access_token'  => '',
			'refresh_token' => '',
			'auth_code'     => '',
			'last_checked'  => '',
			'debug_mode'    => 0,
		);
	}

	private function set_default_options( $settings = false ) {
		$default_settings = $this->default_options();

		if ( ! $settings ) {
			$settings = $this->get_options();
		}

		$this->settings = new stdClass();

		foreach ( $default_settings as $setting => $default ) {
			if ( is_object( $settings ) && isset( $settings->{$setting} ) ) {
				$this->settings->{$setting} = $settings->{$setting};
			}

			if ( ! isset( $this->settings->{$setting} ) ) {
				$this->settings->{$setting} = $default;
			}
		}
	}

	private function get_options() {
		$settings = get_option( $this->option_name );
		if ( ! empty( $settings ) ) {
			$this->set_default_options( $settings );
		}

		return $this->settings;
	}

	public function update( $params ) {
		$settings = $this->default_options();
		$auth_code = $this->settings->auth_code;

		foreach ( $settings as $setting => $default ) {
			if ( isset( $params[ 'frm_ctct_' . $setting ] ) ) {
				$this->settings->{$setting} = $params[ 'frm_ctct_' . $setting ];
			}
			$this->settings->debug_mode = isset( $params['frm_ctct_debug_mode'] ) ? $params['frm_ctct_debug_mode'] : 0;
			unset( $setting, $default );
		}

		if ( $this->settings->auth_code !== $auth_code ) {
			$ctct_api = new FrmCtctAPI();
			$response = $ctct_api->get_access_token( $this->settings->auth_code );
			if ( ! empty( $response ) ) {
				if ( isset( $response->access_token ) ) {
					$ctct_api->set_tokens( $response, $this );
				} else {
					echo '<div class="error">' . esc_html( print_r( $response, 1 ) ) . '</div>';
				}
			}
		}
	}

	public function store() {
		update_option( $this->option_name, $this->settings );
	}

}
