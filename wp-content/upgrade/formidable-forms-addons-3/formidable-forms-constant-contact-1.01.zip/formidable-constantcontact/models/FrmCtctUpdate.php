<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmCtctUpdate extends FrmAddon {

	public $plugin_file;
	public $plugin_name = 'Constant Contact';
	public $download_id = 20826884;
	public $version = '1.01';

	public function __construct() {
		$this->plugin_file = FrmCtctAppController::path() . '/formidable-constantcontact.php';
		parent::__construct();
	}

	public static function load_hooks() {
		add_filter( 'frm_include_addon_page', '__return_true' );
		new FrmCtctUpdate();
	}
}
