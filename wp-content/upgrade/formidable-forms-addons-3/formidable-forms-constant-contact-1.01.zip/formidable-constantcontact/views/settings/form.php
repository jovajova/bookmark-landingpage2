<table class="form-table">

	<?php if ( ! empty( $settings->access_token ) && ! empty( $settings->last_checked ) ) { ?>
		<tr class="form-field" valign="top">
			<td>
				<label><?php esc_html_e( 'Connection last checked', 'formidable-ctct' ); ?></label>
			</td>
			<td>
				<?php if ( $settings->last_checked > strtotime( '-1 day' ) ) { ?>
					<div class="updated frm_updated_message inline">
						<?php
						esc_html_e( 'Connection successful', 'formidable-ctct' );
						echo esc_html(
							' (' . round( ( time() - $settings->last_checked ) / ( 60 * 60 * 24 ), 0, PHP_ROUND_HALF_UP ) .
							' ' . __( 'day(s) ago', 'formidable-ctct' ) . ') '
						);
						?>
					</div>
				<?php } ?>
			</td>
		</tr>
	<?php } ?>
	<tr class="form-field" valign="top">
		<td>
			<label for="frm_ctct_auth_code">
				<?php
				if ( empty( $settings->access_token ) || ! empty( $settings->last_checked ) ) {
					esc_html_e( 'Reauthorize', 'formidable-ctct' );
				} else {
					esc_html_e( 'Authorization Code', 'formidable-ctct' );
				}
				?>
			</label>
		</td>
		<td>
			<input type="text" name="frm_ctct_auth_code" id="frm_ctct_auth_code" value="<?php echo esc_attr( $settings->auth_code ); ?>" class="frm_long_input" />
			<p style="margin-bottom:10px;">
				<a href="<?php echo esc_url( $ctct_api->auth_url() ); ?>" class="button" target="_blank" rel="noopener">
					<?php esc_html_e( 'Get Authorization Code', 'formidable-ctct' ); ?>
				</a>
			</p>
			<p class="howto">
				<?php
				/* translators: %1$s: Start link HTML, %2$s: end link HTML */
				printf( esc_html__( 'Learn more about the %1$sAuthorization code%2$s', 'formidable-ctct' ), '<a href="https://formidableforms.com/knowledgebase/constant-contact-forms/" target="_blank">', '</a>' );
				?>
			</p>
		</td>
	</tr>

	<tr class="form-field" valign="top">
		<td>
			<?php esc_html_e( 'Debug Mode', 'formidable-ctct' ); ?>
		</td>
		<td>
			<label>
				<input type="checkbox" name="frm_ctct_debug_mode" value="1" <?php checked( $settings->debug_mode, 1 ); ?> />
				<?php esc_html_e( 'Yes, I want to see Constant Contact responses on form submit.', 'formidable-ctct' ); ?>
			</label>
		</td>
	</tr>

</table>
