<div class="error">
	<p>
		<?php
		_e( 'Formidable MailChimp requires that Formidable Pro version 2.0 or greater be installed. Until then, keep Formidable MailChimp activated only to continue enjoying this insightful message.', 'frmmlcmp' );
		?>
	</p>
</div>