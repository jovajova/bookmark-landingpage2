<h3><?php esc_html_e( 'Emails', 'frmreg' ); ?></h3>
<a href="javascript:void(0)" class="button frm-button-secondary frmreg_admin_email">
	<?php esc_html_e( 'Create admin email', 'frmreg' ); ?>
</a>
<a href="javascript:void(0)" class="button frm-button-secondary frmreg_user_email">
	<?php esc_html_e( 'Create user email', 'frmreg' ); ?>
</a>
