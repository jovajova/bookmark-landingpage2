<div class="error">
	<p>
		<?php
		_e( 'Formidable Registration requires that Formidable Pro version 2.0 or greater be installed. Until then, keep Formidable Registration activated only to continue enjoying this insightful message.', 'frmreg' );
		?>
	</p>
</div>