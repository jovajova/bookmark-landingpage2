<?php

class FrmWpmlAppHelper {

	public static function plugin_folder() {
		return basename( self::plugin_path() );
	}

	public static function plugin_path() {
		return dirname( dirname( __FILE__ ) );
	}

	public static function plugin_url() {
		return plugins_url( '', self::plugin_path() . '/formidable-wpml.php' );
	}

	/**
	 * @since 1.05
	 */
	public static function get_default_language() {
		return apply_filters( 'wpml_default_language', null );
	}

	/**
	 * @since 1.05
	 */
	public static function get_current_language() {
		return apply_filters( 'wpml_current_language', null );
	}
}
