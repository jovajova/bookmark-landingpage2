<?php

class FrmLogAppHelper {

	public static function plugin_path() {
		return dirname( dirname( __FILE__ ) );
	}
}